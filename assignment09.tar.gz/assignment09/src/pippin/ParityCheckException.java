package pippin;

public class ParityCheckException extends RuntimeException {
	public ParityCheckException(){
		super();
	}
	
	public ParityCheckException(String message){
		super(message);
	}
}
