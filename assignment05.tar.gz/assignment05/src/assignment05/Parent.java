package assignment05;

public class Parent {
	private String pName;
	public void setpName(String name){
		pName = name;
	}
	public void print(){
		System.out.println(pName);
	}
	
}
