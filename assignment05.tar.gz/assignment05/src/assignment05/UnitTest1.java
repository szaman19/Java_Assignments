package assignment05;

import static org.junit.Assert.*;

import org.junit.Test;

public class UnitTest1 {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
