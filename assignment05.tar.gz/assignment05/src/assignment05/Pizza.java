package assignment05;

public interface Pizza extends Comparable<Pizza> {
	String getDescription();
	double getCost();
	
}
