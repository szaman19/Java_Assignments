package assignment05;

public class SmallCheesePizza implements Pizza {

	@Override
	public int compareTo(Pizza o) {
		// TODO Auto-generated method stub
		return 1;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Small Cheese Pizza";
	}

	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return 8.0;
	}

}
