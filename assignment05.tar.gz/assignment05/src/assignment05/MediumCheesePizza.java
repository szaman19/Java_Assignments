package assignment05;

public class MediumCheesePizza implements Pizza {

	@Override
	public int compareTo(Pizza o) {
		// TODO Auto-generated method stub
		return 1;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Medium Cheese Pizza";
	}
	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return 10.0;
	}

}
