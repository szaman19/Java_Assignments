package assignment03;

public enum Direction{
UP,DOWN
}
