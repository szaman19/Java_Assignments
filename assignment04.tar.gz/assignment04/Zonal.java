package assignment04;
public enum Zonal{
  EAST,WEST
}
