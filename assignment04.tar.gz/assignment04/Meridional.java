package assignment04;
public enum Meridional{
  NORTH,SOUTH
}
