package lab06;

import java.util.ArrayList;

public interface ComputationMethod {
	int compute(ArrayList<Card> cards);
}
