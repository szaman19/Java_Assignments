package lab09;

public interface Expr {
	public int eval();
}
